# ai model on object storage example


f(x) = ax+b
a = 12
b = 3.25